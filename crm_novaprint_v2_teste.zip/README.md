# CRM Novaprint - Versao 2.0 Teste

Esta pasta contem uma versao de teste do CRM Novaprint.

Alteracoes principais:

- Menu lateral no estilo plataforma.
- Modulo de Retornos dentro do CRM.
- Agendamento de retorno por cliente e por orcamento.
- Campos de data, hora, motivo, observacao e responsavel.
- Lista de retornos pendentes ordenada por urgencia.
- Indicadores de retornos vencidos, hoje e amanha.
- Botao Concluido com historico preservado.

Importante:

- Esta versao e apenas para teste.
- A versao atual do CRM nao deve ser substituida definitivamente ate confirmacao.
- Se aprovada, esta sera considerada a versao 2.0.

Para Streamlit Cloud:

1. Suba os arquivos desta pasta para o GitHub.
2. Configure `streamlit_app.py` como arquivo principal.
3. Configure os secrets do Streamlit com os tokens do GestaoClick e Google Sheets.
