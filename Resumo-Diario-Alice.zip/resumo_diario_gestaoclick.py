import json
import queue
import re
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk


API_BASE = "https://api.gestaoclick.com"
APP_DIR = Path.home() / "ResumoDiarioGestaoClick"
DB_PATH = APP_DIR / "resumo_diario.db"
CONFIG_PATH = APP_DIR / "config.json"
OPEN_STATUS_BLOCKLIST = (
    "aprovado",
    "cancelado",
    "confirmado",
    "concretizado",
    "convertido",
    "finalizado",
    "faturado",
    "perdido",
    "recusado",
    "vendido",
)
LOSS_REASONS = ("Preco", "Prazo", "Sem resposta", "Comprou concorrente", "Sem estoque", "Outro")


def clean(value):
    return "" if value is None else str(value).strip()


def normalized_name(value):
    return re.sub(r"[^a-z0-9]", "", clean(value).lower())


def phone_digits(value):
    return re.sub(r"\D", "", clean(value))


def money(value):
    try:
        amount = Decimal(clean(value) or "0")
    except InvalidOperation:
        amount = Decimal("0")
    text = f"{amount:,.2f}"
    return "R$ " + text.replace(",", "_").replace(".", ",").replace("_", ".")


def parse_date(value):
    text = clean(value)
    if not text:
        return None
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y"):
        try:
            return datetime.strptime(text[:19], fmt).date()
        except ValueError:
            pass
    return None


def expiry_date(budget):
    created = parse_date(budget.get("data"))
    validity = clean(budget.get("validade")).lower()
    if not created or not validity:
        return None
    direct = parse_date(validity)
    if direct:
        return direct
    match = re.search(r"(\d+)", validity)
    return created + timedelta(days=int(match.group(1))) if match else None


def relative_day(value):
    parsed = parse_date(value)
    if not parsed:
        return "Sem registro"
    days = (date.today() - parsed).days
    if days == 0:
        return "Hoje"
    if days == 1:
        return "Ontem"
    if days > 1:
        return f"{days} dias atras"
    if days == -1:
        return "Amanha"
    return f"Em {abs(days)} dias"


def commercial_period(reference=None):
    reference = reference or date.today()
    if reference.day <= 20:
        previous_month_end = reference.replace(day=1) - timedelta(days=1)
        start = previous_month_end.replace(day=21)
        end = reference.replace(day=20)
    else:
        start = reference.replace(day=21)
        next_month = (reference.replace(day=28) + timedelta(days=4)).replace(day=1)
        end = next_month.replace(day=20)
    return start, end


def client_history_tabs(client, budgets, sales):
    budgets = sorted(
        budgets,
        key=lambda item: clean(item.get("data")),
        reverse=True,
    )
    valid_sales = [
        item
        for item in sales
        if "cancelad" not in clean(item.get("nome_situacao")).lower()
    ]
    valid_sales.sort(key=lambda item: clean(item.get("data")), reverse=True)
    products_quoted = {}
    products_sold = {}
    contacts = []

    def collect_products(records, target):
        for record in records:
            for wrapper in record.get("produtos") or []:
                product = wrapper.get("produto") or {}
                name = clean(product.get("nome_produto")) or "Produto sem nome"
                quantity = float(product.get("quantidade") or 0)
                target[name] = target.get(name, 0) + quantity

    collect_products(budgets, products_quoted)
    collect_products(valid_sales, products_sold)
    contact_pattern = re.compile(r"^\[ATENDIMENTO ([^\]]+)\]\s*(.*)$")
    for budget in budgets:
        for line in clean(budget.get("observacoes_interna")).splitlines():
            match = contact_pattern.match(line.strip())
            if match:
                contacts.append(
                    f"{match.group(1)} | Orc. {budget.get('codigo')} | {match.group(2)}"
                )

    budget_values = [float(item.get("valor_total") or 0) for item in budgets]
    sales_values = [float(item.get("valor_total") or 0) for item in valid_sales]
    last_budget = budgets[0] if budgets else None
    last_sale = valid_sales[0] if valid_sales else None
    summary = [
        f"CLIENTE: {clean(client.get('nome'))}",
        f"CNPJ/CPF: {clean(client.get('cnpj') or client.get('cpf'))}",
        f"TELEFONE: {clean(client.get('celular') or client.get('telefone')) or 'Nao informado'}",
        f"E-MAIL: {clean(client.get('email')) or 'Nao informado'}",
        "",
        f"Orcamentos encontrados: {len(budgets)}",
        f"Valor total orcado: {money(sum(budget_values))}",
        f"Ticket medio orcado: {money(sum(budget_values) / len(budget_values) if budget_values else 0)}",
        f"Ultimo orcamento: {clean(last_budget.get('data')) if last_budget else 'Nenhum'}",
        "",
        f"Vendas validas: {len(valid_sales)}",
        f"Valor total comprado: {money(sum(sales_values))}",
        f"Ticket medio comprado: {money(sum(sales_values) / len(sales_values) if sales_values else 0)}",
        f"Ultima compra: {clean(last_sale.get('data')) if last_sale else 'Nenhuma'}",
    ]
    budget_lines = [
        f"{clean(item.get('data'))} | Orc. {clean(item.get('codigo'))} | "
        f"{money(item.get('valor_total') or 0)} | {clean(item.get('nome_situacao'))} | "
        f"{clean(item.get('nome_vendedor')) or 'Sem vendedor'}"
        for item in budgets
    ]
    sale_lines = [
        f"{clean(item.get('data'))} | Venda {clean(item.get('codigo') or item.get('id'))} | "
        f"{money(item.get('valor_total') or 0)} | {clean(item.get('nome_situacao'))} | "
        f"{clean(item.get('nome_vendedor')) or 'Sem vendedor'}"
        for item in valid_sales
    ]
    product_names = sorted(set(products_quoted) | set(products_sold))
    product_lines = [
        f"{name} | Cotado: {products_quoted.get(name, 0):g} | "
        f"Vendido: {products_sold.get(name, 0):g}"
        for name in product_names
    ]
    return (
        ("Resumo", "\n".join(summary)),
        ("Orcamentos", "\n".join(budget_lines) or "Nenhum orcamento encontrado."),
        ("Vendas", "\n".join(sale_lines) or "Nenhuma venda valida encontrada."),
        ("Produtos", "\n".join(product_lines) or "Nenhum produto encontrado."),
        ("Atendimentos", "\n".join(contacts) or "Nenhum atendimento registrado."),
    )


class GestaoClickAPI:
    def __init__(self, access_token, secret_token):
        self.headers = {
            "Content-Type": "application/json",
            "access-token": access_token,
            "secret-access-token": secret_token,
        }
        self.last_request = 0.0

    def request(self, path, params=None, method="GET", body=None):
        elapsed = time.monotonic() - self.last_request
        if elapsed < 0.36:
            time.sleep(0.36 - elapsed)
        url = API_BASE + path
        if params:
            url += "?" + urllib.parse.urlencode(params)
        data = json.dumps(body).encode("utf-8") if body is not None else None
        request = urllib.request.Request(url, data=data, headers=self.headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=40) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"GestaoClick retornou erro {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Nao foi possivel acessar o GestaoClick: {exc.reason}") from exc
        finally:
            self.last_request = time.monotonic()
        if payload.get("status") != "success":
            raise RuntimeError(payload.get("message") or "Resposta inesperada do GestaoClick.")
        return payload

    def list_all(self, path, params):
        records = []
        page = 1
        while True:
            query = dict(params)
            query.update({"pagina": page, "limite": 100})
            payload = self.request(path, query)
            records.extend(payload.get("data") or [])
            meta = payload.get("meta") or {}
            if not meta.get("proxima_pagina") and len(payload.get("data") or []) < 100:
                break
            page += 1
            if page > 100:
                break
        return records

    def stores(self):
        return self.request("/lojas").get("data") or []

    def users(self, store_id):
        return self.list_all("/usuarios", {"loja_id": store_id})

    def find_client_by_document(self, document, store_id):
        clients = self.list_all(
            "/clientes",
            {"cpf_cnpj": document, "loja_id": store_id},
        )
        wanted = phone_digits(document)
        exact = [
            client
            for client in clients
            if phone_digits(client.get("cnpj") or client.get("cpf")) == wanted
        ]
        return exact[0] if exact else None

    def client_budgets(self, client_id, store_id):
        return self.list_all(
            "/orcamentos",
            {"cliente_id": client_id, "loja_id": store_id},
        )

    def client_sales(self, client_id, store_id):
        return self.list_all(
            "/vendas",
            {"cliente_id": client_id, "loja_id": store_id},
        )

    def budgets(self, start_date, store_id):
        return self.list_all(
            "/orcamentos",
            {"data_inicio": start_date.isoformat(), "loja_id": store_id},
        )

    def sales(self, start_date, store_id):
        return self.list_all(
            "/vendas",
            {"data_inicio": start_date.isoformat(), "loja_id": store_id},
        )

    def budget_statuses(self, store_id):
        return self.list_all("/situacoes_orcamentos", {"loja_id": store_id})

    def budget(self, budget_id, store_id):
        return self.request(f"/orcamentos/{budget_id}", {"loja_id": store_id}).get("data") or {}

    def client(self, client_id, store_id):
        return self.request(f"/clientes/{client_id}", {"loja_id": store_id}).get("data") or {}

    @staticmethod
    def prepare_budget(budget):
        budget["tipo"] = "servico" if budget.get("servicos") and not budget.get("produtos") else "produto"
        for wrapper in budget.get("produtos") or []:
            product = wrapper.get("produto") or {}
            if not product.get("id") and product.get("produto_id"):
                product["id"] = product["produto_id"]
        return budget

    def update_budget(self, budget_id, store_id, budget):
        budget = self.prepare_budget(budget)
        return self.request(
            f"/orcamentos/{budget_id}",
            {"loja_id": store_id},
            method="PUT",
            body=budget,
        ).get("data") or {}

    def update_budget_status(self, budget_id, store_id, status_id):
        budget = self.budget(budget_id, store_id)
        if not budget:
            raise RuntimeError("O orcamento nao foi encontrado no GestaoClick.")
        budget["situacao_id"] = int(status_id)
        return self.update_budget(budget_id, store_id, budget)

    def append_budget_contact(self, budget_id, store_id, channel, outcome, note, seller):
        budget = self.budget(budget_id, store_id)
        if not budget:
            raise RuntimeError("O orcamento nao foi encontrado no GestaoClick.")
        timestamp = datetime.now().strftime("%d/%m/%Y %H:%M")
        entry = f"[ATENDIMENTO {timestamp}] {seller} | {channel} | {outcome}"
        if note:
            entry += f" | {note}"
        previous = clean(budget.get("observacoes_interna"))
        budget["observacoes_interna"] = f"{previous}\n{entry}".strip()
        return self.update_budget(budget_id, store_id, budget)


class Database:
    def __init__(self, path):
        APP_DIR.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path)
        self.connection.row_factory = sqlite3.Row
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS budgets (
                id TEXT PRIMARY KEY,
                code TEXT,
                client_id TEXT,
                client_name TEXT NOT NULL,
                seller_id TEXT,
                seller_name TEXT,
                created_date TEXT,
                status TEXT,
                total REAL NOT NULL DEFAULT 0,
                validity TEXT,
                notes TEXT,
                internal_notes TEXT,
                products_json TEXT NOT NULL DEFAULT '[]',
                commercial_status TEXT NOT NULL DEFAULT 'Novo',
                loss_reason TEXT,
                status_updated_at TEXT,
                synced_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                budget_id TEXT NOT NULL,
                contacted_at TEXT NOT NULL,
                channel TEXT NOT NULL,
                outcome TEXT NOT NULL,
                note TEXT,
                FOREIGN KEY (budget_id) REFERENCES budgets(id)
            );
            CREATE TABLE IF NOT EXISTS followups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                budget_id TEXT NOT NULL,
                scheduled_at TEXT NOT NULL,
                note TEXT,
                completed_at TEXT,
                FOREIGN KEY (budget_id) REFERENCES budgets(id)
            );
            CREATE TABLE IF NOT EXISTS sellers (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1,
                store_id TEXT
            );
            CREATE TABLE IF NOT EXISTS sales (
                id TEXT PRIMARY KEY,
                client_id TEXT,
                client_name TEXT NOT NULL,
                seller_name TEXT,
                sale_date TEXT,
                status TEXT,
                total REAL NOT NULL DEFAULT 0,
                products_json TEXT NOT NULL DEFAULT '[]'
            );
            """
        )
        self.ensure_column("budgets", "products_json", "TEXT NOT NULL DEFAULT '[]'")
        self.ensure_column("budgets", "commercial_status", "TEXT NOT NULL DEFAULT 'Novo'")
        self.ensure_column("budgets", "loss_reason", "TEXT")
        self.ensure_column("budgets", "status_updated_at", "TEXT")
        self.ensure_column("budgets", "pdf_path", "TEXT")
        self.ensure_column("budgets", "needs_approval", "INTEGER NOT NULL DEFAULT 0")
        self.ensure_column("sales", "status", "TEXT")
        self.connection.commit()

    def ensure_column(self, table, column, definition):
        columns = {
            row["name"] for row in self.connection.execute(f"PRAGMA table_info({table})").fetchall()
        }
        if column not in columns:
            self.connection.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

    def replace_budgets(self, budgets):
        ids = [clean(item.get("id")) for item in budgets if clean(item.get("id"))]
        with self.connection:
            if ids:
                placeholders = ",".join("?" for _ in ids)
                self.connection.execute(
                    f"DELETE FROM budgets WHERE id NOT IN ({placeholders})",
                    ids,
                )
            else:
                self.connection.execute("DELETE FROM budgets")
        self.save_budgets(budgets)

    def save_budgets(self, budgets):
        now = datetime.now().isoformat(timespec="seconds")
        with self.connection:
            for item in budgets:
                self.connection.execute(
                    """
                    INSERT INTO budgets (
                        id, code, client_id, client_name, seller_id, seller_name,
                        created_date, status, total, validity, notes, internal_notes,
                        products_json, synced_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(id) DO UPDATE SET
                        code=excluded.code, client_id=excluded.client_id,
                        client_name=excluded.client_name, seller_id=excluded.seller_id,
                        seller_name=excluded.seller_name, created_date=excluded.created_date,
                        status=excluded.status, total=excluded.total, validity=excluded.validity,
                        notes=excluded.notes, internal_notes=excluded.internal_notes,
                        products_json=excluded.products_json,
                        synced_at=excluded.synced_at
                    """,
                    (
                        clean(item.get("id")),
                        clean(item.get("codigo")),
                        clean(item.get("cliente_id")),
                        clean(item.get("nome_cliente")) or "Cliente sem nome",
                        clean(item.get("vendedor_id")),
                        clean(item.get("nome_vendedor")) or "Sem vendedor",
                        clean(item.get("data")),
                        clean(item.get("nome_situacao")),
                        float(item.get("valor_total") or 0),
                        clean(item.get("validade")),
                        clean(item.get("observacoes")),
                        clean(item.get("observacoes_interna")),
                        json.dumps(self.extract_products(item), ensure_ascii=False),
                        now,
                    ),
                )
                self.import_contacts_from_notes(
                    clean(item.get("id")),
                    clean(item.get("observacoes_interna")),
                )

    def import_contacts_from_notes(self, budget_id, notes):
        pattern = re.compile(
            r"^\[ATENDIMENTO ([^\]]+)\]\s*([^|]+)\|\s*([^|]+)\|\s*([^|]+)(?:\|\s*(.*))?$"
        )
        for line in notes.splitlines():
            match = pattern.match(line.strip())
            if not match:
                continue
            when_text, _seller, channel, outcome, note = match.groups()
            try:
                contacted_at = datetime.strptime(
                    when_text.strip(), "%d/%m/%Y %H:%M"
                ).isoformat(timespec="minutes")
            except ValueError:
                continue
            values = (
                budget_id,
                contacted_at,
                channel.strip(),
                outcome.strip(),
                clean(note),
            )
            exists = self.connection.execute(
                """
                SELECT 1 FROM contacts
                WHERE budget_id=? AND contacted_at=? AND channel=? AND outcome=?
                AND COALESCE(note, '')=?
                """,
                values,
            ).fetchone()
            if not exists:
                self.connection.execute(
                    """
                    INSERT INTO contacts (budget_id, contacted_at, channel, outcome, note)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    values,
                )

    @staticmethod
    def extract_products(item):
        products = []
        for wrapper in item.get("produtos") or []:
            product = wrapper.get("produto") or {}
            products.append(
                {
                    "id": clean(product.get("produto_id") or product.get("id")),
                    "name": clean(product.get("nome_produto")) or "Produto sem nome",
                    "quantity": float(product.get("quantidade") or 0),
                    "total": float(product.get("valor_total") or 0),
                    "cost": float(product.get("valor_custo") or 0),
                }
            )
        return products

    def replace_sales(self, sales):
        with self.connection:
            self.connection.execute("DELETE FROM sales")
            for item in sales:
                self.connection.execute(
                    """
                    INSERT INTO sales (
                        id, client_id, client_name, seller_name, sale_date, status,
                        total, products_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        clean(item.get("id")),
                        clean(item.get("cliente_id")),
                        clean(item.get("nome_cliente")) or "Cliente sem nome",
                        clean(item.get("nome_vendedor")) or "Sem vendedor",
                        clean(item.get("data")),
                        clean(item.get("nome_situacao")),
                        float(item.get("valor_total") or 0),
                        json.dumps(self.extract_products(item), ensure_ascii=False),
                    ),
                )

    def save_sellers(self, sellers, store_id):
        with self.connection:
            self.connection.execute("DELETE FROM sellers")
            for seller in sellers:
                if clean(seller.get("ativo")) == "0":
                    continue
                seller_id = clean(seller.get("id"))
                seller_name = clean(seller.get("nome"))
                if seller_id and seller_name:
                    self.connection.execute(
                        "INSERT INTO sellers (id, name, active, store_id) VALUES (?, ?, 1, ?)",
                        (seller_id, seller_name, clean(store_id)),
                    )

    def add_contact(self, budget_id, channel, outcome, note):
        with self.connection:
            self.connection.execute(
                """
                INSERT INTO contacts (budget_id, contacted_at, channel, outcome, note)
                VALUES (?, ?, ?, ?, ?)
                """,
                (budget_id, datetime.now().isoformat(timespec="seconds"), channel, outcome, note),
            )
            status = "Quente" if outcome == "Respondeu" else "Em negociacao"
            if outcome == "Pediu retorno":
                status = "Retorno"
            elif outcome == "Sem interesse":
                status = "Perdido"
            self.connection.execute(
                """
                UPDATE budgets SET commercial_status=?, status_updated_at=?
                WHERE id=?
                """,
                (status, datetime.now().isoformat(timespec="seconds"), budget_id),
            )

    def add_followup(self, budget_id, scheduled_at, note):
        with self.connection:
            self.connection.execute(
                "INSERT INTO followups (budget_id, scheduled_at, note) VALUES (?, ?, ?)",
                (budget_id, scheduled_at, note),
            )
            self.connection.execute(
                "UPDATE budgets SET commercial_status='Retorno', status_updated_at=? WHERE id=?",
                (datetime.now().isoformat(timespec="seconds"), budget_id),
            )

    def mark_lost(self, budget_id, reason):
        with self.connection:
            self.connection.execute(
                """
                UPDATE budgets
                SET commercial_status='Perdido', loss_reason=?, status_updated_at=?
                WHERE id=?
                """,
                (reason, datetime.now().isoformat(timespec="seconds"), budget_id),
            )

    def update_automatic_statuses(self):
        today = date.today()
        rows = self.connection.execute(
            "SELECT id, created_date, validity, status, commercial_status FROM budgets"
        ).fetchall()
        with self.connection:
            for row in rows:
                original = clean(row["status"]).lower()
                current = clean(row["commercial_status"]) or "Novo"
                if any(
                    word in original
                    for word in ("confirmado", "concretizado", "aprovado", "vendido", "faturado")
                ):
                    new_status = "Convertido"
                elif current == "Perdido":
                    continue
                else:
                    expires = expiry_date(
                        {"data": row["created_date"], "validade": row["validity"]}
                    )
                    new_status = "Perdido" if expires and expires < today else current
                if new_status != current:
                    self.connection.execute(
                        "UPDATE budgets SET commercial_status=?, status_updated_at=? WHERE id=?",
                        (new_status, datetime.now().isoformat(timespec="seconds"), row["id"]),
                    )

    def complete_followups(self, budget_id):
        with self.connection:
            self.connection.execute(
                """
                UPDATE followups SET completed_at=?
                WHERE budget_id=? AND completed_at IS NULL AND date(scheduled_at) <= date('now', 'localtime')
                """,
                (datetime.now().isoformat(timespec="seconds"), budget_id),
            )

    def sellers(self):
        rows = self.connection.execute(
            "SELECT name AS seller_name FROM sellers WHERE active=1 ORDER BY name"
        ).fetchall()
        if not rows:
            rows = self.connection.execute(
                """
                SELECT DISTINCT seller_name FROM budgets
                WHERE seller_name IS NOT NULL AND seller_name <> ''
                ORDER BY seller_name
                """
            ).fetchall()
        return [row["seller_name"] for row in rows if row["seller_name"]]

    def budgets_with_activity(self, seller=None):
        params = []
        where = "WHERE date(b.created_date) >= date('now', 'localtime', '-30 days')"
        if seller and seller != "Todas":
            where += " AND b.seller_name=?"
            params.append(seller)
        return self.connection.execute(
            f"""
            SELECT b.*,
                (SELECT MAX(contacted_at) FROM contacts c WHERE c.budget_id=b.id) AS last_contact,
                (SELECT outcome FROM contacts c WHERE c.budget_id=b.id
                    ORDER BY contacted_at DESC LIMIT 1) AS last_outcome,
                (SELECT scheduled_at FROM followups f WHERE f.budget_id=b.id
                    AND f.completed_at IS NULL ORDER BY scheduled_at LIMIT 1) AS next_followup,
                (SELECT note FROM followups f WHERE f.budget_id=b.id
                    AND f.completed_at IS NULL ORDER BY scheduled_at LIMIT 1) AS followup_note,
                (SELECT COUNT(*) FROM contacts c WHERE c.budget_id=b.id) AS contact_count
                ,(SELECT COUNT(*) FROM sales s WHERE s.client_id=b.client_id) AS purchase_count
                ,(SELECT COUNT(*) FROM budgets b2 WHERE b2.client_id=b.client_id) AS budget_count
            FROM budgets b
            {where}
            ORDER BY b.created_date DESC
            """,
            params,
        ).fetchall()

    def budget_detail(self, budget_id):
        return self.connection.execute(
            "SELECT * FROM budgets WHERE id=?", (budget_id,)
        ).fetchone()

    def client_history(self, client_id):
        budgets = self.connection.execute(
            "SELECT * FROM budgets WHERE client_id=? ORDER BY created_date DESC", (client_id,)
        ).fetchall()
        sales = self.connection.execute(
            """
            SELECT * FROM sales WHERE client_id=?
            AND lower(COALESCE(status, '')) NOT LIKE '%cancelad%'
            ORDER BY sale_date DESC
            """,
            (client_id,),
        ).fetchall()
        contacts = self.connection.execute(
            """
            SELECT c.*, b.code, b.client_name FROM contacts c
            JOIN budgets b ON b.id=c.budget_id
            WHERE b.client_id=? ORDER BY c.contacted_at DESC
            """,
            (client_id,),
        ).fetchall()
        return budgets, sales, contacts

    def performance(self, period_start, period_end):
        return self.connection.execute(
            """
            SELECT s.name AS seller,
                COUNT(DISTINCT b.id) AS budgets,
                COUNT(DISTINCT c.id) AS contacts,
                COUNT(DISTINCT CASE WHEN b.commercial_status='Convertido' THEN b.id END) AS converted,
                COALESCE((SELECT SUM(b2.total) FROM budgets b2
                    WHERE b2.seller_name=s.name AND b2.commercial_status='Perdido'
                    AND date(b2.created_date)>=date('now','localtime','-30 days')), 0) AS lost_value,
                COALESCE((SELECT SUM(v.total) FROM sales v
                    WHERE v.seller_name=s.name
                    AND date(v.sale_date) BETWEEN date(?) AND date(?)
                    AND lower(COALESCE(v.status, '')) NOT LIKE '%cancelad%'), 0)
                    AS sold_value,
                SUM(CASE WHEN c.id IS NULL AND julianday('now')-julianday(b.created_date)>2
                    THEN 1 ELSE 0 END) AS untouched
            FROM sellers s
            LEFT JOIN budgets b ON b.seller_name=s.name
                AND date(b.created_date) >= date('now', 'localtime', '-30 days')
            LEFT JOIN contacts c ON c.budget_id=b.id
            GROUP BY s.name ORDER BY s.name
            """,
            (period_start.isoformat(), period_end.isoformat()),
        ).fetchall()

    def product_report(self):
        quoted = {}
        sold = {}
        for row in self.connection.execute(
            "SELECT products_json FROM budgets WHERE date(created_date)>=date('now','localtime','-30 days')"
        ):
            for item in json.loads(row["products_json"] or "[]"):
                name = item["name"]
                quoted[name] = quoted.get(name, 0) + float(item.get("quantity") or 0)
        for row in self.connection.execute(
            """
            SELECT products_json FROM sales
            WHERE lower(COALESCE(status, '')) NOT LIKE '%cancelad%'
            """
        ):
            for item in json.loads(row["products_json"] or "[]"):
                name = item["name"]
                sold[name] = sold.get(name, 0) + float(item.get("quantity") or 0)
        names = set(quoted) | set(sold)
        return sorted(
            [(name, quoted.get(name, 0), sold.get(name, 0)) for name in names],
            key=lambda item: (-item[1], item[0].lower()),
        )

    def sales_total_between(self, start_date, end_date):
        row = self.connection.execute(
            """
            SELECT COALESCE(SUM(total), 0) AS total FROM sales
            WHERE date(sale_date) BETWEEN date(?) AND date(?)
            AND lower(COALESCE(status, '')) NOT LIKE '%cancelad%'
            """,
            (start_date.isoformat(), end_date.isoformat()),
        ).fetchone()
        return float(row["total"] or 0)


@dataclass
class Opportunity:
    budget_id: str
    priority: int
    icon: str
    reason: str
    client: str
    seller: str
    total: float
    last_contact: str
    action: str
    category: str
    score: int
    commercial_status: str
    is_hot: bool
    is_return: bool


def is_open_status(status):
    normalized = clean(status).lower()
    return not any(word in normalized for word in OPEN_STATUS_BLOCKLIST)


def build_opportunities(rows):
    today = date.today()
    opportunities = []
    counters = {"calls": 0, "hot": 0, "returns": 0, "untouched": 0, "expiring": 0}
    for row in rows:
        item = dict(row)
        if (
            not is_open_status(item["status"])
            or item["commercial_status"] in ("Convertido", "Perdido")
        ):
            continue
        created = parse_date(item["created_date"])
        age = (today - created).days if created else 0
        last_contact = parse_date(item["last_contact"])
        followup = parse_date(item["next_followup"])
        expires = expiry_date({"data": item["created_date"], "validade": item["validity"]})
        total = float(item["total"] or 0)
        products = json.loads(item.get("products_json") or "[]")
        revenue = sum(float(product.get("total") or 0) for product in products)
        cost = sum(
            float(product.get("cost") or 0) * float(product.get("quantity") or 0)
            for product in products
        )
        margin = ((revenue - cost) / revenue * 100) if revenue and cost else 0
        days_without_contact = (today - last_contact).days if last_contact else age
        score = 20
        score += min(int(total / 1000) * 2, 30)
        score += min(int(item["purchase_count"] or 0) * 12, 24)
        score += min(int(item["budget_count"] or 0) * 3, 12)
        score += 10 if margin >= 30 else 0
        score += 12 if last_contact and days_without_contact <= 3 else 0
        score -= min(max(days_without_contact - 7, 0), 20)
        score = max(0, min(score, 100))
        categories = []
        is_return = False
        is_hot = False

        if followup and followup <= today:
            categories.append((110, "RETORNO", "Retorno agendado para hoje ou atrasado", "Retornar"))
            counters["returns"] += 1
            is_return = True
        elif not last_contact and age == 2:
            categories.append(
                (
                    100,
                    "RETORNO",
                    "Orcamento com 2 dias: ligar hoje",
                    "Ligar",
                )
            )
            counters["returns"] += 1
            is_return = True
        if not last_contact and age == 3:
            categories.append((105, "SEM CONTATO", "Urgente: orcamento com 3 dias", "Ligar urgente"))
            counters["untouched"] += 1
        elif not last_contact and age >= 4:
            categories.append((108, "SEM CONTATO", f"Risco de perda: orcamento com {age} dias", "Priorizar"))
            counters["untouched"] += 1
        hot_signals = []
        if total >= 5000:
            hot_signals.append("alto valor")
        if int(item["purchase_count"] or 0) > 0:
            hot_signals.append("ja comprou")
        if int(item["budget_count"] or 0) > 1:
            hot_signals.append("cliente recorrente")
        if margin >= 30:
            hot_signals.append("boa margem")
        if last_contact and days_without_contact <= 3:
            hot_signals.append("contato recente")
        if score >= 65 and len(hot_signals) >= 2 and age <= 14:
            categories.append(
                (90, "QUENTE", "Oportunidade: " + ", ".join(hot_signals[:3]), "Priorizar")
            )
            counters["hot"] += 1
            is_hot = True
        if expires and 0 <= (expires - today).days <= 3:
            categories.append((85, "VENCENDO", f"Validade termina em {(expires - today).days} dias", "Renovar"))
            counters["expiring"] += 1
        if not last_contact and age == 1:
            categories.append(
                (
                    60,
                    "NOVO",
                    "Orcamento com 1 dia: acompanhamento normal",
                    "Acompanhar",
                )
            )
        if not categories:
            continue
        priority, category, reason, action = max(categories, key=lambda value: value[0])
        icon = {
            "RETORNO": "R",
            "QUENTE": "Q",
            "VENCENDO": "V",
            "SEM CONTATO": "!",
            "NOVO": "N",
        }[category]
        opportunities.append(
            Opportunity(
                budget_id=item["id"],
                priority=priority,
                icon=icon,
                reason=reason,
                client=item["client_name"],
                seller=item["seller_name"],
                total=total,
                last_contact=relative_day(item["last_contact"] or item["created_date"]),
                action=action,
                category=category,
                score=score,
                commercial_status=item["commercial_status"],
                is_hot=is_hot,
                is_return=is_return,
            )
        )
        if category in ("RETORNO", "SEM CONTATO", "VENCENDO"):
            counters["calls"] += 1
    opportunities.sort(
        key=lambda item: (-item.priority, -item.score, -item.total, item.client.lower())
    )
    return opportunities, counters


class ContactDialog(tk.Toplevel):
    def __init__(self, parent, client):
        super().__init__(parent)
        self.result = None
        self.title(f"Registrar contato - {client}")
        self.geometry("470x310")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        body = ttk.Frame(self, padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=client, font=("", 13, "bold")).pack(anchor="w")
        ttk.Label(body, text="Canal").pack(anchor="w", pady=(16, 4))
        self.channel = ttk.Combobox(body, values=("Ligacao", "WhatsApp", "E-mail"), state="readonly")
        self.channel.set("Ligacao")
        self.channel.pack(fill="x")
        ttk.Label(body, text="Resultado").pack(anchor="w", pady=(12, 4))
        self.outcome = ttk.Combobox(
            body,
            values=("Respondeu", "Nao respondeu", "Pediu retorno", "Sem interesse"),
            state="readonly",
        )
        self.outcome.set("Respondeu")
        self.outcome.pack(fill="x")
        ttk.Label(body, text="Observacao").pack(anchor="w", pady=(12, 4))
        self.note = tk.Text(body, height=4)
        self.note.pack(fill="x")
        ttk.Button(body, text="Salvar contato", command=self.save).pack(anchor="e", pady=(14, 0))
        self.wait_window()

    def save(self):
        self.result = (self.channel.get(), self.outcome.get(), self.note.get("1.0", "end").strip())
        self.destroy()


class FollowupDialog(tk.Toplevel):
    def __init__(self, parent, client):
        super().__init__(parent)
        self.result = None
        self.title(f"Agendar retorno - {client}")
        self.geometry("470x260")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        body = ttk.Frame(self, padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=client, font=("", 13, "bold")).pack(anchor="w")
        ttk.Label(body, text="Data e hora (DD/MM/AAAA HH:MM)").pack(anchor="w", pady=(16, 4))
        self.when = ttk.Entry(body)
        self.when.insert(0, (datetime.now() + timedelta(days=1)).replace(hour=9, minute=0).strftime("%d/%m/%Y %H:%M"))
        self.when.pack(fill="x")
        ttk.Label(body, text="Motivo do retorno").pack(anchor="w", pady=(12, 4))
        self.note = ttk.Entry(body)
        self.note.pack(fill="x")
        ttk.Button(body, text="Agendar retorno", command=self.save).pack(anchor="e", pady=(18, 0))
        self.wait_window()

    def save(self):
        try:
            parsed = datetime.strptime(self.when.get().strip(), "%d/%m/%Y %H:%M")
        except ValueError:
            messagebox.showwarning("Data invalida", "Use o formato DD/MM/AAAA HH:MM.", parent=self)
            return
        self.result = (parsed.isoformat(timespec="minutes"), self.note.get().strip())
        self.destroy()


class ChoiceDialog(tk.Toplevel):
    def __init__(self, parent, title, label, choices):
        super().__init__(parent)
        self.result = None
        self.title(title)
        self.geometry("430x170")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        body = ttk.Frame(self, padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=label).pack(anchor="w")
        self.value = ttk.Combobox(body, values=choices, state="readonly")
        self.value.set(choices[0])
        self.value.pack(fill="x", pady=12)
        ttk.Button(body, text="Confirmar", command=self.save).pack(anchor="e")
        self.wait_window()

    def save(self):
        self.result = self.value.get()
        self.destroy()


class TextWindow(tk.Toplevel):
    def __init__(self, parent, title, tabs):
        super().__init__(parent)
        self.title(title)
        self.geometry("900x650")
        self.minsize(720, 500)
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=12, pady=12)
        for tab_name, content in tabs:
            frame = ttk.Frame(notebook, padding=10)
            notebook.add(frame, text=tab_name)
            text = tk.Text(frame, wrap="word", font=("Consolas", 10), padx=10, pady=10)
            text.insert("1.0", content)
            text.configure(state="disabled")
            scroll = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
            text.configure(yscrollcommand=scroll.set)
            text.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Resumo Diario - GestaoClick")
        self.geometry("1480x800")
        self.minsize(1180, 680)
        self.db = Database(DB_PATH)
        self.result_queue = queue.Queue()
        self.opportunities = []
        self.filtered_opportunities = []
        self.quick_filter = "Todas"
        self.period_start, self.period_end = commercial_period()
        self.sales_total = self.db.sales_total_between(self.period_start, self.period_end)
        self.sort_column = "default"
        self.sort_reverse = False
        self.config_data = self.load_config()
        self.seller_emails = self.config_data.get("seller_emails", {})
        self.configure_style()
        self.build()
        self.refresh_dashboard()
        self.after(150, self.poll)

    def configure_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"), foreground="#172033")
        style.configure("Subtitle.TLabel", font=("Segoe UI", 10), foreground="#64748b")
        style.configure("CardValue.TLabel", font=("Segoe UI", 24, "bold"))
        style.configure("CardTitle.TLabel", font=("Segoe UI", 10), foreground="#64748b")
        style.configure("TButton", font=("Segoe UI", 10), padding=(12, 7))
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 7))
        style.configure("Treeview", rowheight=32, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

    def load_config(self):
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def save_config(self):
        APP_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "access_token": self.access_var.get().strip(),
            "secret_token": self.secret_var.get().strip(),
            "monthly_goal": self.goal_var.get().strip(),
            "seller": self.seller_var.get(),
            "seller_emails": self.seller_emails,
        }
        CONFIG_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def build(self):
        shell = ttk.Frame(self)
        shell.pack(fill="both", expand=True)
        sidebar = tk.Frame(shell, bg="#172033", width=190)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        main = ttk.Frame(shell)
        main.pack(side="right", fill="both", expand=True)

        tk.Label(
            sidebar, text="NOVAPRINT", bg="#172033", fg="white",
            font=("Segoe UI", 15, "bold"), padx=18, pady=22,
        ).pack(anchor="w")
        nav_items = (
            ("Resumo diario", self.focus_dashboard),
            ("Orcamentos", self.show_budgets_overview),
            ("Consultar CNPJ", self.search_client_by_cnpj),
            ("Historico cliente", self.show_history),
            ("Relatorios", self.show_reports),
            ("Enviar por e-mail", self.email_daily_summary),
            ("Sincronizar", self.sync),
        )
        for label, command in nav_items:
            tk.Button(
                sidebar,
                text=label,
                command=command,
                bg="#172033",
                fg="#e2e8f0",
                activebackground="#25324a",
                activeforeground="white",
                relief="flat",
                anchor="w",
                padx=18,
                pady=11,
                font=("Segoe UI", 10),
            ).pack(fill="x")
        tk.Label(
            sidebar,
            text="Ciclo da meta\n21 a 20",
            bg="#172033",
            fg="#94a3b8",
            justify="left",
            padx=18,
            pady=20,
            font=("Segoe UI", 9),
        ).pack(side="bottom", anchor="w")

        header = ttk.Frame(main, padding=(20, 16, 20, 10))
        header.pack(fill="x")
        title = ttk.Frame(header)
        title.pack(side="left")
        ttk.Label(title, text="Resumo Diario", style="Title.TLabel").pack(anchor="w")
        self.date_label = ttk.Label(
            title,
            text=date.today().strftime("%d/%m/%Y") + " | Sua fila de prioridades",
            style="Subtitle.TLabel",
        )
        self.date_label.pack(anchor="w")
        actions = ttk.Frame(header)
        actions.pack(side="right")
        self.progress = ttk.Progressbar(actions, mode="indeterminate", length=120)
        self.progress.pack(side="left", padx=(0, 10))
        ttk.Button(actions, text="Modo demonstracao", command=self.load_demo).pack(side="left", padx=4)
        ttk.Button(actions, text="Sincronizar GestaoClick", style="Accent.TButton", command=self.sync).pack(side="left", padx=4)

        connection = ttk.LabelFrame(main, text="Conexao e filtros", padding=10)
        connection.pack(fill="x", padx=20, pady=(0, 12))
        ttk.Label(connection, text="Access token").grid(row=0, column=0, sticky="w")
        ttk.Label(connection, text="Secret access token").grid(row=0, column=1, sticky="w")
        ttk.Label(connection, text="Vendedora - Loja NOVAPRINT").grid(row=0, column=2, sticky="w")
        ttk.Label(connection, text="Meta do ciclo (dia 21 a 20)").grid(row=0, column=3, sticky="w")
        self.access_var = tk.StringVar(value=self.config_data.get("access_token", ""))
        self.secret_var = tk.StringVar(value=self.config_data.get("secret_token", ""))
        self.seller_var = tk.StringVar(value=self.config_data.get("seller", "Todas"))
        self.goal_var = tk.StringVar(value=self.config_data.get("monthly_goal", "300000"))
        ttk.Entry(connection, textvariable=self.access_var, show="*", width=30).grid(row=1, column=0, padx=(0, 8), sticky="ew")
        ttk.Entry(connection, textvariable=self.secret_var, show="*", width=30).grid(row=1, column=1, padx=(0, 8), sticky="ew")
        self.seller_combo = ttk.Combobox(connection, textvariable=self.seller_var, state="readonly", width=25)
        self.seller_combo["values"] = ("Todas",)
        self.seller_combo.grid(row=1, column=2, padx=(0, 8), sticky="ew")
        self.seller_combo.bind("<<ComboboxSelected>>", lambda _event: self.refresh_dashboard())
        ttk.Entry(connection, textvariable=self.goal_var, width=16).grid(row=1, column=3, padx=(0, 8), sticky="ew")
        ttk.Button(connection, text="Aplicar", command=self.apply_filters).grid(row=1, column=4)
        for column in range(4):
            connection.columnconfigure(column, weight=1)

        cards = ttk.Frame(main, padding=(20, 0))
        cards.pack(fill="x")
        self.card_vars = {}
        card_specs = (
            ("calls", "Clientes para ligar", "#2563eb"),
            ("hot", "Oportunidades quentes", "#dc2626"),
            ("returns", "Retornos hoje", "#7c3aed"),
            ("untouched", "Sem contato", "#d97706"),
        )
        for index, (key, label, color) in enumerate(card_specs):
            card = tk.Frame(cards, bg="white", highlightbackground="#dbe2ea", highlightthickness=1, padx=16, pady=12)
            card.grid(row=0, column=index, padx=(0 if index == 0 else 5, 5), sticky="ew")
            self.card_vars[key] = tk.StringVar(value="0")
            tk.Label(card, textvariable=self.card_vars[key], bg="white", fg=color, font=("Segoe UI", 24, "bold")).pack(anchor="w")
            tk.Label(card, text=label, bg="white", fg="#64748b", font=("Segoe UI", 10)).pack(anchor="w")
            cards.columnconfigure(index, weight=1)

        meta = ttk.Frame(main, padding=(20, 12, 20, 8))
        meta.pack(fill="x")
        self.summary_var = tk.StringVar(value="Nenhum dado sincronizado.")
        ttk.Label(meta, textvariable=self.summary_var, style="Subtitle.TLabel").pack(side="left")
        self.goal_summary_var = tk.StringVar(value="")
        ttk.Label(meta, textvariable=self.goal_summary_var, font=("Segoe UI", 10, "bold")).pack(side="right")

        quick_filters = ttk.Frame(main, padding=(20, 0, 20, 8))
        quick_filters.pack(fill="x")
        ttk.Label(quick_filters, text="Mostrar:").pack(side="left", padx=(0, 8))
        self.quick_filter_buttons = {}
        for label in ("Todas", "Oportunidades quentes", "Retornos hoje"):
            button = ttk.Button(
                quick_filters,
                text=label,
                command=lambda value=label: self.set_quick_filter(value),
            )
            button.pack(side="left", padx=(0, 6))
            self.quick_filter_buttons[label] = button

        columns = ("priority", "score", "status", "client", "seller", "value", "contact", "reason", "action")
        tree_frame = ttk.Frame(main)
        tree_frame.pack(fill="both", expand=True, padx=20)
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse")
        headings = ("Prioridade", "Pontos", "Status", "Cliente", "Vendedora", "Valor", "Ultimo contato", "Motivo", "Acao")
        widths = (90, 60, 105, 190, 145, 105, 115, 230, 80)
        for key, heading, width in zip(columns, headings, widths):
            self.tree.heading(key, text=heading, command=lambda column=key: self.sort_by(column))
            self.tree.column(key, width=width, anchor="e" if key == "value" else "w")
        horizontal = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.tree.xview)
        vertical = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(xscrollcommand=horizontal.set, yscrollcommand=vertical.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal.grid(row=1, column=0, sticky="ew")
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)
        self.tree.tag_configure("QUENTE", background="#fff1f2")
        self.tree.tag_configure("RETORNO", background="#f5f3ff")
        self.tree.tag_configure("VENCENDO", background="#fff7ed")
        self.tree.tag_configure("SEM CONTATO", background="#fffbeb")
        self.tree.tag_configure("NOVO", background="#eff6ff")
        self.tree.bind("<Double-1>", lambda _event: self.register_contact())

        footer = ttk.Frame(main, padding=(20, 10, 20, 14), height=58)
        footer.pack(side="bottom", fill="x", before=tree_frame)
        footer.pack_propagate(False)
        self.message_var = tk.StringVar(value="Use o modo demonstracao ou sincronize com o GestaoClick.")
        ttk.Label(footer, textvariable=self.message_var, style="Subtitle.TLabel").pack(side="left")
        ttk.Button(footer, text="Sugestao", command=self.assistant_advice).pack(side="right", padx=(8, 0))
        ttk.Button(footer, text="Marcar perda", command=self.mark_lost).pack(side="right", padx=(8, 0))
        ttk.Button(footer, text="WhatsApp", command=self.whatsapp_message).pack(side="right", padx=(8, 0))
        ttk.Button(footer, text="Agendar retorno", command=self.schedule_followup).pack(side="right", padx=(8, 0))
        ttk.Button(footer, text="Registrar contato", style="Accent.TButton", command=self.register_contact).pack(side="right")

    def apply_filters(self):
        self.save_config()
        self.refresh_dashboard()

    def focus_dashboard(self):
        self.tree.focus_set()
        if self.tree.get_children():
            first = self.tree.get_children()[0]
            self.tree.see(first)

    def sort_by(self, column):
        if self.sort_column == column:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_column = column
            self.sort_reverse = column in ("score", "value")
        self.apply_sort()
        self.render_opportunities()
        current = self.summary_var.get().split(" | ordem:")[0]
        direction = "decrescente" if self.sort_reverse else "crescente"
        self.summary_var.set(f"{current} | ordem: {column} ({direction})")

    def apply_sort(self):
        key_map = {
            "priority": lambda item: item.priority,
            "score": lambda item: item.score,
            "status": lambda item: item.commercial_status.lower(),
            "client": lambda item: item.client.lower(),
            "seller": lambda item: item.seller.lower(),
            "value": lambda item: item.total,
            "contact": lambda item: item.last_contact.lower(),
            "reason": lambda item: item.reason.lower(),
            "action": lambda item: item.action.lower(),
        }
        if self.sort_column == "default":
            self.opportunities.sort(
                key=lambda item: (-item.priority, -item.score, -item.total, item.client.lower())
            )
            return
        self.opportunities.sort(
            key=key_map[self.sort_column],
            reverse=self.sort_reverse,
        )

    def set_quick_filter(self, value):
        self.quick_filter = value
        self.render_opportunities()
        self.update_summary()

    def visible_opportunities(self):
        if self.quick_filter == "Oportunidades quentes":
            return [item for item in self.opportunities if item.is_hot]
        if self.quick_filter == "Retornos hoje":
            return [item for item in self.opportunities if item.is_return]
        return list(self.opportunities)

    def render_opportunities(self):
        self.filtered_opportunities = self.visible_opportunities()
        for row_id in self.tree.get_children():
            self.tree.delete(row_id)
        for index, item in enumerate(self.filtered_opportunities):
            self.tree.insert(
                "",
                "end",
                iid=str(index),
                values=(
                    item.category,
                    item.score,
                    item.commercial_status,
                    item.client,
                    item.seller,
                    money(item.total),
                    item.last_contact,
                    item.reason,
                    item.action,
                ),
                tags=(item.category,),
            )

    def selected(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("Selecione um cliente", "Clique em uma linha da lista primeiro.")
            return None
        index = int(selection[0])
        return self.filtered_opportunities[index]

    def update_summary(self, counters=None):
        if counters is None:
            counters = getattr(
                self,
                "last_counters",
                {"expiring": 0},
            )
        self.summary_var.set(
            f"{len(self.filtered_opportunities)} exibidos de {len(self.opportunities)} | "
            f"filtro: {self.quick_filter} | "
            f"{counters['expiring']} orcamentos vencendo | "
            f"ordem: {'prioridade automatica' if self.sort_column == 'default' else self.sort_column}"
        )

    def register_contact(self):
        item = self.selected()
        if not item:
            return
        dialog = ContactDialog(self, item.client)
        if not dialog.result:
            return
        channel, outcome, note = dialog.result
        if item.budget_id.startswith("demo-"):
            self.finish_contact(item, channel, outcome, note, remote=False)
            return
        access = self.access_var.get().strip()
        secret = self.secret_var.get().strip()
        if not access or not secret:
            messagebox.showwarning(
                "Tokens necessarios",
                "Informe os tokens para registrar o atendimento no GestaoClick.",
            )
            return
        self.message_var.set(f"Registrando atendimento de {item.client} no GestaoClick...")

        def task():
            api = GestaoClickAPI(access, secret)
            store = next(
                (
                    value
                    for value in api.stores()
                    if "novaprint" in normalized_name(value.get("nome"))
                ),
                None,
            )
            if not store:
                raise RuntimeError("A loja NOVAPRINT nao foi encontrada.")
            api.append_budget_contact(
                item.budget_id,
                store["id"],
                channel,
                outcome,
                note,
                item.seller,
            )

            def done():
                self.finish_contact(item, channel, outcome, note)

            return done

        self.run_task(task)

    def finish_contact(self, item, channel, outcome, note, remote=True):
        self.db.add_contact(item.budget_id, channel, outcome, note)
        self.db.complete_followups(item.budget_id)
        self.refresh_dashboard()
        destination = "localmente e no GestaoClick" if remote else "no modo demonstracao"
        self.message_var.set(f"Contato com {item.client} salvo {destination}.")
        if outcome == "Pediu retorno":
            self.schedule_followup(item)

    def schedule_followup(self, item=None):
        item = item or self.selected()
        if not item:
            return
        dialog = FollowupDialog(self, item.client)
        if not dialog.result:
            return
        when, note = dialog.result
        self.db.add_followup(item.budget_id, when, note)
        self.refresh_dashboard()
        self.message_var.set(f"Retorno de {item.client} agendado.")

    def refresh_sellers(self):
        sellers = ("Todas", *self.db.sellers())
        self.seller_combo["values"] = sellers
        if self.seller_var.get() not in sellers:
            self.seller_var.set("Todas")

    def refresh_dashboard(self):
        self.refresh_sellers()
        self.db.update_automatic_statuses()
        rows = self.db.budgets_with_activity(self.seller_var.get())
        self.opportunities, counters = build_opportunities(rows)
        self.last_counters = counters
        self.apply_sort()
        for key in self.card_vars:
            self.card_vars[key].set(str(counters[key]))
        self.render_opportunities()
        self.update_summary(counters)
        try:
            goal = float(self.goal_var.get().replace(".", "").replace(",", "."))
        except ValueError:
            goal = 0
        missing = max(goal - self.sales_total, 0)
        self.goal_summary_var.set(
            f"Meta {self.period_start.strftime('%d/%m')} a {self.period_end.strftime('%d/%m')}: "
            f"{money(goal)} | Vendido: {money(self.sales_total)} | Falta: {money(missing)}"
        )

    def mark_lost(self):
        item = self.selected()
        if not item:
            return
        dialog = ChoiceDialog(self, "Motivo da perda", item.client, LOSS_REASONS)
        if not dialog.result:
            return
        reason = dialog.result
        if not messagebox.askyesno(
            "Confirmar encerramento",
            f"Marcar {item.client} como perdido?\n\n"
            "A situacao deste orcamento tambem sera alterada para "
            "'Concretizado' no GestaoClick.",
        ):
            return
        if item.budget_id.startswith("demo-"):
            self.db.mark_lost(item.budget_id, reason)
            self.refresh_dashboard()
            self.message_var.set(f"{item.client} marcado como perdido no modo demonstracao.")
            return
        access = self.access_var.get().strip()
        secret = self.secret_var.get().strip()
        if not access or not secret:
            messagebox.showwarning(
                "Tokens necessarios",
                "Informe os tokens do GestaoClick antes de marcar a perda.",
            )
            return
        self.message_var.set(f"Encerrando o orcamento de {item.client} no GestaoClick...")

        def task():
            api = GestaoClickAPI(access, secret)
            store = next(
                (
                    value
                    for value in api.stores()
                    if "novaprint" in normalized_name(value.get("nome"))
                ),
                None,
            )
            if not store:
                raise RuntimeError("A loja NOVAPRINT nao foi encontrada.")
            statuses = api.budget_statuses(store["id"])
            concretized = next(
                (
                    value
                    for value in statuses
                    if normalized_name(value.get("nome")) == "concretizado"
                ),
                None,
            )
            if not concretized:
                available = ", ".join(clean(value.get("nome")) for value in statuses)
                raise RuntimeError(
                    "A situacao 'Concretizado' nao existe no GestaoClick. "
                    f"Situacoes disponiveis: {available}."
                )
            updated = api.update_budget_status(
                item.budget_id,
                store["id"],
                concretized["id"],
            )

            def done():
                self.db.mark_lost(item.budget_id, reason)
                self.refresh_dashboard()
                remote_status = clean(updated.get("nome_situacao")) or "Concretizado"
                self.message_var.set(
                    f"{item.client}: perdido no aplicativo e {remote_status} no GestaoClick."
                )
                messagebox.showinfo(
                    "Orcamento encerrado",
                    f"Motivo da perda: {reason}\n"
                    f"Situacao no GestaoClick: {remote_status}",
                )

            return done

        self.run_task(task)

    def whatsapp_message(self):
        item = self.selected()
        if not item:
            return
        first_name = item.client.split()[0].title()
        message = (
            f"Ola {first_name}, tudo bem? Vi que seu orcamento de {money(item.total)} "
            "ficou pendente. Posso te ajudar a concluir ou ajustar alguma informacao hoje?"
        )
        self.clipboard_clear()
        self.clipboard_append(message)
        if item.budget_id.startswith("demo-"):
            messagebox.showinfo("Mensagem copiada", message)
            return
        choice = messagebox.askyesnocancel(
            "WhatsApp",
            f"A mensagem ja foi copiada:\n\n{message}\n\n"
            "Deseja abrir a conversa no WhatsApp agora?\n"
            "Sim = abrir | Nao = somente copiar",
        )
        if choice is None:
            return
        if not choice:
            self.message_var.set("Mensagem copiada para colar no WhatsApp.")
            return
        access = self.access_var.get().strip()
        secret = self.secret_var.get().strip()
        detail = self.db.budget_detail(item.budget_id)
        if not access or not secret or not detail:
            messagebox.showwarning(
                "Telefone",
                "A mensagem foi copiada, mas nao foi possivel consultar o telefone.",
            )
            return
        self.message_var.set(f"Consultando telefone de {item.client}...")

        def task():
            api = GestaoClickAPI(access, secret)
            store = next(
                (
                    value
                    for value in api.stores()
                    if "novaprint" in normalized_name(value.get("nome"))
                ),
                None,
            )
            if not store:
                raise RuntimeError("A loja NOVAPRINT nao foi encontrada.")
            client = api.client(detail["client_id"], store["id"])
            candidates = [client.get("celular"), client.get("telefone")]
            for wrapper in client.get("contatos") or []:
                candidates.append((wrapper.get("contato") or {}).get("contato"))
            number = next(
                (phone_digits(value) for value in candidates if len(phone_digits(value)) >= 10),
                "",
            )
            if len(number) in (10, 11):
                number = "55" + number
            if not number:
                raise RuntimeError(
                    "O cliente nao possui celular ou telefone valido no GestaoClick. "
                    "A mensagem continua copiada."
                )
            url = "https://wa.me/" + number + "?text=" + urllib.parse.quote(message)

            def done():
                webbrowser.open(url)
                self.message_var.set(f"WhatsApp aberto para {item.client}.")

            return done

        self.run_task(task)

    def assistant_advice(self):
        item = self.selected()
        if not item:
            return
        detail = self.db.budget_detail(item.budget_id)
        budgets, sales, contacts = self.db.client_history(detail["client_id"])
        reasons = [f"pontuacao {item.score}/100", f"orcamento de {money(item.total)}"]
        if sales:
            reasons.append(f"cliente ja comprou {len(sales)} vez(es) no historico")
        if len(budgets) > 1:
            reasons.append(f"cliente recorrente com {len(budgets)} orcamentos")
        if not contacts:
            action = "Ligar hoje e registrar o resultado."
            reasons.append("nenhum contato registrado")
        elif item.category == "RETORNO":
            action = "Cumprir o retorno agendado antes de abordar outros leads."
        elif item.score >= 70:
            action = "Priorizar contato pessoal e confirmar o principal obstaculo para fechar."
        else:
            action = "Enviar uma mensagem curta e programar o proximo retorno."
        messagebox.showinfo(
            "Sugestao comercial",
            f"{action}\n\nPor que: " + "; ".join(reasons) + ".",
        )

    def email_daily_summary(self):
        seller = self.seller_var.get()
        if not seller or seller == "Todas":
            messagebox.showinfo(
                "Selecione a vendedora",
                "Escolha uma vendedora no filtro antes de gerar o resumo por e-mail.",
            )
            return
        recipient = simpledialog.askstring(
            "E-mail da vendedora",
            f"Informe o e-mail de {seller}:",
            initialvalue=self.seller_emails.get(seller, ""),
            parent=self,
        )
        if recipient is None:
            return
        recipient = recipient.strip()
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", recipient):
            messagebox.showwarning("E-mail invalido", "Informe um endereco de e-mail valido.")
            return
        self.seller_emails[seller] = recipient
        self.save_config()

        opportunities, counters = build_opportunities(
            self.db.budgets_with_activity(seller)
        )
        returns = [item for item in opportunities if item.is_return]
        hot = [item for item in opportunities if item.is_hot and not item.is_return]
        other = [
            item for item in opportunities
            if not item.is_return and not item.is_hot
        ]
        subject = f"Resumo diario - {seller} - {date.today().strftime('%d/%m/%Y')}"

        def lines(items, limit):
            result = []
            for index, item in enumerate(items[:limit], start=1):
                result.append(
                    f"{index}. {item.client}\n"
                    f"   Valor: {money(item.total)}\n"
                    f"   Acao: {item.action}\n"
                    f"   Motivo: {item.reason}"
                )
            if len(items) > limit:
                result.append(
                    f"\nMais {len(items) - limit} item(ns) estao disponiveis na aplicacao."
                )
            return result

        body_lines = [
            f"Bom dia, {seller.title()}.",
            "",
            f"Esta e sua agenda comercial de {date.today().strftime('%d/%m/%Y')}.",
            "",
            "RESUMO",
            f"- Clientes para ligar: {counters['calls']}",
            f"- Retornos para hoje: {counters['returns']}",
            f"- Oportunidades quentes: {counters['hot']}",
            f"- Orcamentos sem contato: {counters['untouched']}",
            "",
            "1. RETORNOS PARA HOJE",
            *(lines(returns, 8) or ["Nenhum retorno para hoje."]),
            "",
            "2. OPORTUNIDADES QUENTES",
            *(lines(hot, 8) or ["Nenhuma oportunidade quente pendente."]),
            "",
            "3. OUTRAS PRIORIDADES",
            *(lines(other, 8) or ["Nenhuma outra atividade pendente."]),
            "",
            "Abra o Resumo Diario para consultar a lista completa, registrar contatos "
            "e agendar retornos.",
            "",
            "Bom trabalho.",
        ]
        body = "\r\n".join(body_lines)
        self.clipboard_clear()
        self.clipboard_append(body)
        mailto = (
            f"mailto:{urllib.parse.quote(recipient, safe='@')}?"
            f"subject={urllib.parse.quote(subject, safe='')}&"
            f"body={urllib.parse.quote(body, safe='')}"
        )
        opened = webbrowser.open(mailto)
        if opened:
            self.message_var.set(
                f"Resumo de {seller} aberto no programa de e-mail e copiado."
            )
        else:
            messagebox.showinfo(
                "Resumo copiado",
                "Nao foi possivel abrir o programa de e-mail. "
                "O resumo completo foi copiado para colar manualmente.",
            )

    def search_client_by_cnpj(self):
        document = simpledialog.askstring(
            "Consultar cliente",
            "Informe o CNPJ com 14 digitos:",
            parent=self,
        )
        if document is None:
            return
        document = phone_digits(document)
        if len(document) != 14:
            messagebox.showwarning(
                "CNPJ invalido",
                "Informe um CNPJ com 14 digitos.",
            )
            return
        access = self.access_var.get().strip()
        secret = self.secret_var.get().strip()
        if not access or not secret:
            messagebox.showwarning(
                "Tokens necessarios",
                "Informe os tokens do GestaoClick antes de consultar o cliente.",
            )
            return
        self.message_var.set(f"Consultando o CNPJ {document} no GestaoClick...")

        def task():
            api = GestaoClickAPI(access, secret)
            store = next(
                (
                    value
                    for value in api.stores()
                    if "novaprint" in normalized_name(value.get("nome"))
                ),
                None,
            )
            if not store:
                raise RuntimeError("A loja NOVAPRINT nao foi encontrada.")
            client = api.find_client_by_document(document, store["id"])
            if not client:
                raise RuntimeError(
                    "Nenhum cliente com este CNPJ foi encontrado na NOVAPRINT."
                )
            budgets = api.client_budgets(client["id"], store["id"])
            sales = api.client_sales(client["id"], store["id"])
            tabs = client_history_tabs(client, budgets, sales)

            def done():
                TextWindow(
                    self,
                    f"Historico por CNPJ - {clean(client.get('nome'))}",
                    tabs,
                )
                self.message_var.set(
                    f"{clean(client.get('nome'))}: {len(budgets)} orcamentos "
                    f"e {len(sales)} vendas encontradas."
                )

            return done

        self.run_task(task)

    def show_history(self):
        item = self.selected()
        if not item:
            return
        detail = self.db.budget_detail(item.budget_id)
        budgets, sales, contacts = self.db.client_history(detail["client_id"])
        products = []
        for budget in budgets:
            for product in json.loads(budget["products_json"] or "[]"):
                products.append(product["name"])
        average = sum(float(row["total"]) for row in budgets) / len(budgets) if budgets else 0
        last_sale = sales[0] if sales else None
        summary = [
            f"CLIENTE: {detail['client_name']}",
            f"VENDEDOR RESPONSAVEL: {detail['seller_name']}",
            f"ORCAMENTOS: {len(budgets)}",
            f"VALOR MEDIO COTADO: {money(average)}",
            f"ULTIMA COMPRA: {last_sale['sale_date'] if last_sale else 'Sem compra no historico'}",
            f"ULTIMA LIGACAO: {contacts[0]['contacted_at'] if contacts else 'Sem contato registrado'}",
            "",
            "PRODUTOS COTADOS",
            *[f"- {name}" for name in sorted(set(products))],
        ]
        budget_lines = [
            f"{row['created_date']} | Orc. {row['code']} | {money(row['total'])} | "
            f"{row['commercial_status']} | {row['seller_name']}"
            + (f" | PDF: {row['pdf_path']}" if row["pdf_path"] else "")
            for row in budgets
        ]
        sale_lines = [
            f"{row['sale_date']} | {money(row['total'])} | {row['seller_name']}" for row in sales
        ]
        contact_lines = [
            f"{row['contacted_at']} | {row['channel']} | {row['outcome']} | {row['note'] or ''}"
            for row in contacts
        ]
        TextWindow(
            self,
            f"Historico - {detail['client_name']}",
            (
                ("Resumo", "\n".join(summary)),
                ("Orcamentos", "\n".join(budget_lines) or "Nenhum orcamento."),
                ("Compras", "\n".join(sale_lines) or "Nenhuma compra no periodo."),
                ("Contatos", "\n".join(contact_lines) or "Nenhum contato registrado."),
            ),
        )

    def show_budgets_overview(self):
        rows = self.db.connection.execute(
            """
            SELECT code, client_name, seller_name, created_date, status,
                commercial_status, total, validity
            FROM budgets
            ORDER BY date(created_date) DESC, CAST(code AS INTEGER) DESC
            LIMIT 200
            """
        ).fetchall()
        today = date.today()
        generated_today = 0
        open_count = 0
        approved = 0
        lost = 0
        open_value = 0.0
        approved_value = 0.0
        lines = []
        for row in rows:
            created = parse_date(row["created_date"])
            if created == today:
                generated_today += 1
            status = clean(row["status"]).lower()
            commercial = clean(row["commercial_status"])
            if "aprovad" in status or commercial == "Convertido":
                approved += 1
                approved_value += float(row["total"] or 0)
            elif "perdid" in status or commercial == "Perdido":
                lost += 1
            elif is_open_status(row["status"]):
                open_count += 1
                open_value += float(row["total"] or 0)
            marker = "APROVADO" if "aprovad" in status else commercial.upper()
            lines.append(
                f"{row['created_date']} | No {row['code']} | {row['client_name']} | "
                f"{row['seller_name']} | {money(row['total'])} | {marker}"
            )
        decided = approved + lost
        rate = approved / decided * 100 if decided else 0
        summary = "\n".join(
            (
                f"Gerados hoje: {generated_today}",
                f"Em aberto: {open_count}",
                f"Aprovados/concretizados: {approved}",
                f"Perdidos: {lost}",
                f"Valor em aberto: {money(open_value)}",
                f"Valor aprovado: {money(approved_value)}",
                f"Taxa de aprovacao: {rate:.1f}%",
            )
        )
        TextWindow(
            self,
            "Orcamentos",
            (
                ("Resumo", summary),
                ("Orcamentos recentes", "\n".join(lines) or "Nenhum orcamento."),
            ),
        )

    def show_reports(self):
        performance_lines = []
        forecast = 0.0
        audit_lines = []
        for row in self.db.performance(self.period_start, self.period_end):
            budgets = int(row["budgets"] or 0)
            converted = int(row["converted"] or 0)
            rate = (converted / budgets * 100) if budgets else 0
            performance_lines.append(
                f"{row['seller']}: {budgets} orcamentos | {row['contacts'] or 0} contatos | "
                f"{rate:.1f}% conversao | vendido {money(row['sold_value'] or 0)} | "
                f"perdido {money(row['lost_value'] or 0)} | "
                f"{row['untouched'] or 0} sem contato"
            )
            if int(row["untouched"] or 0):
                audit_lines.append(
                    f"{row['seller']}: {row['untouched']} clientes sem contato depois de 2 dias."
                )
        for item in self.opportunities:
            forecast += item.total * (item.score / 100)
        product_lines = [
            f"{name}: cotado {quoted:g} | vendido {sold:g} | conversao "
            f"{(sold / quoted * 100 if quoted else 0):.1f}%"
            for name, quoted, sold in self.db.product_report()[:100]
        ]
        losses = self.db.connection.execute(
            """
            SELECT COALESCE(loss_reason, 'Nao informado') reason, COUNT(*) total,
                SUM(total) value FROM budgets WHERE commercial_status='Perdido'
            GROUP BY COALESCE(loss_reason, 'Nao informado') ORDER BY total DESC
            """
        ).fetchall()
        loss_lines = [
            f"{row['reason']}: {row['total']} orcamentos | {money(row['value'] or 0)}"
            for row in losses
        ]
        TextWindow(
            self,
            "Relatorios comerciais",
            (
                ("Performance", "\n".join(performance_lines) or "Sem dados."),
                ("Previsao", f"Previsao ponderada da fila atual: {money(forecast)}"),
                ("Auditoria", "\n".join(audit_lines) or "Nenhuma pendencia encontrada."),
                ("Produtos", "\n".join(product_lines) or "Sem produtos sincronizados."),
                ("Perdas", "\n".join(loss_lines) or "Nenhuma perda registrada."),
            ),
        )

    def run_task(self, function):
        self.progress.start(10)
        threading.Thread(target=self.worker, args=(function,), daemon=True).start()

    def worker(self, function):
        try:
            self.result_queue.put(("ok", function()))
        except Exception as exc:
            self.result_queue.put(("error", exc))

    def poll(self):
        try:
            kind, result = self.result_queue.get_nowait()
        except queue.Empty:
            self.after(150, self.poll)
            return
        self.progress.stop()
        if kind == "error":
            messagebox.showerror("Sincronizacao nao concluida", str(result))
            self.message_var.set("Confira os tokens e sua conexao.")
        else:
            result()
        self.after(150, self.poll)

    def sync(self):
        access = self.access_var.get().strip()
        secret = self.secret_var.get().strip()
        if not access or not secret:
            messagebox.showwarning("Tokens necessarios", "Informe os dois tokens da API do GestaoClick.")
            return
        self.save_config()
        self.message_var.set("Localizando a loja NOVAPRINT no GestaoClick...")

        def task():
            api = GestaoClickAPI(access, secret)
            stores = api.stores()
            store = next(
                (item for item in stores if "novaprint" in normalized_name(item.get("nome"))),
                None,
            )
            if not store:
                available = ", ".join(clean(item.get("nome")) for item in stores) or "nenhuma"
                raise RuntimeError(
                    "A loja NOVAPRINT nao foi encontrada para estes tokens. "
                    f"Lojas disponiveis: {available}."
                )
            store_id = clean(store.get("id"))
            users = api.users(store_id)
            budgets = api.budgets(date.today() - timedelta(days=30), store_id)
            sales = api.sales(date.today() - timedelta(days=365), store_id)
            period_start, period_end = commercial_period()
            sales_total = sum(
                float(item.get("valor_total") or 0)
                for item in sales
                if parse_date(item.get("data"))
                and period_start <= parse_date(item.get("data")) <= period_end
                and "cancelad" not in clean(item.get("nome_situacao")).lower()
            )

            def done():
                self.db.replace_budgets(budgets)
                self.db.replace_sales(sales)
                self.db.save_sellers(users, store_id)
                self.db.update_automatic_statuses()
                self.period_start, self.period_end = period_start, period_end
                self.sales_total = sales_total
                self.refresh_dashboard()
                self.message_var.set(
                    f"Loja NOVAPRINT: {len(users)} usuarios, {len(budgets)} orcamentos "
                    f"e {len(sales)} vendas no historico."
                )
            return done

        self.run_task(task)

    def load_demo(self):
        today = date.today()
        demo = [
            {"id": "demo-1", "codigo": "1001", "cliente_id": "1", "nome_cliente": "Maria", "vendedor_id": "10", "nome_vendedor": "Ana", "data": (today - timedelta(days=4)).isoformat(), "nome_situacao": "Em aberto", "valor_total": "12000", "validade": "7 dias", "observacoes": "", "observacoes_interna": ""},
            {"id": "demo-2", "codigo": "1002", "cliente_id": "2", "nome_cliente": "Empresa XYZ", "vendedor_id": "10", "nome_vendedor": "Ana", "data": (today - timedelta(days=6)).isoformat(), "nome_situacao": "Em aberto", "valor_total": "18000", "validade": "10 dias", "observacoes": "", "observacoes_interna": ""},
            {"id": "demo-3", "codigo": "1003", "cliente_id": "3", "nome_cliente": "Joao Silva", "vendedor_id": "10", "nome_vendedor": "Ana", "data": (today - timedelta(days=3)).isoformat(), "nome_situacao": "Pendente", "valor_total": "8500", "validade": "10 dias", "observacoes": "", "observacoes_interna": ""},
            {"id": "demo-4", "codigo": "1004", "cliente_id": "4", "nome_cliente": "Carlos", "vendedor_id": "11", "nome_vendedor": "Beatriz", "data": (today - timedelta(days=5)).isoformat(), "nome_situacao": "Em aberto", "valor_total": "2300", "validade": "10 dias", "observacoes": "", "observacoes_interna": ""},
            {"id": "demo-5", "codigo": "1005", "cliente_id": "5", "nome_cliente": "Construtora ABC", "vendedor_id": "11", "nome_vendedor": "Beatriz", "data": (today - timedelta(days=2)).isoformat(), "nome_situacao": "Em negociacao", "valor_total": "25000", "validade": "5 dias", "observacoes": "Cliente avaliando proposta", "observacoes_interna": ""},
        ]
        self.db.save_budgets(demo)
        self.db.add_contact("demo-1", "WhatsApp", "Respondeu", "Pediu prazo para decidir.")
        self.db.add_contact("demo-5", "Ligacao", "Respondeu", "Decisor recebeu a proposta.")
        self.db.add_followup("demo-1", datetime.now().replace(hour=14, minute=0).isoformat(timespec="minutes"), "Confirmar decisao.")
        self.sales_total = 180000
        self.refresh_dashboard()
        self.message_var.set("Dados demonstrativos carregados. Teste registrar contato e agendar retorno.")


if __name__ == "__main__":
    App().mainloop()
