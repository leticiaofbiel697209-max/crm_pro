@echo off
setlocal
set "PYTHON=C:\Users\Gabriel\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%PYTHON%" (
  "%PYTHON%" "%~dp0resumo_diario_gestaoclick.py"
) else if exist "%LocalAppData%\Programs\Python\Python313\python.exe" (
  "%LocalAppData%\Programs\Python\Python313\python.exe" "%~dp0resumo_diario_gestaoclick.py"
) else if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
  "%LocalAppData%\Programs\Python\Python312\python.exe" "%~dp0resumo_diario_gestaoclick.py"
) else if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (
  "%LocalAppData%\Programs\Python\Python311\python.exe" "%~dp0resumo_diario_gestaoclick.py"
) else (
  py -3 "%~dp0resumo_diario_gestaoclick.py"
)
if errorlevel 1 (
  echo.
  echo Python nao encontrado. Instale pelo site https://www.python.org/downloads/windows/
  pause
)
